import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="crop_irradiance",
    version="0.0.1",
    author="Rami ALBASHA",
    author_email="rami.albacha@yahoo.com",
    description="a library for simulating irradiance absorption by crops canopies",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/RamiALBASHA/crop_irradiance",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
