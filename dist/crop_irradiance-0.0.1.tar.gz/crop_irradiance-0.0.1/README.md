# irradiance
a library for simulating irradiance absorption by crops canopies
